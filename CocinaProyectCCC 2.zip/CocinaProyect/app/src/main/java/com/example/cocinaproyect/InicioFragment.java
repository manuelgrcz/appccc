package com.example.cocinaproyect;

import androidx.fragment.app.Fragment;

public class InicioFragment extends Fragment {
}

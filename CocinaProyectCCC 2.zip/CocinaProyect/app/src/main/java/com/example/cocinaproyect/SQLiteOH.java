package com.example.cocinaproyect;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
public class SQLiteOH extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "favoritos.db";
    private static final int DATABASE_VERSION = 1;

    // Nombres de las tablas
    public static final String TABLE_CATEGORIES = "Categories";
    public static final String TABLE_PLATES = "Plates";

    // Columnas de la tabla Categories
    public static final String COLUMN_CATEGORY_ID = "_id";
    public static final String COLUMN_CATEGORY_NAME = "name";

    // Columnas de la tabla Plates
    public static final String COLUMN_PLATE_ID = "_id";
    public static final String COLUMN_PLATE_NAME = "name";
    public static final String COLUMN_PLATE_DESCRIPTION = "description";
    public static final String COLUMN_PLATE_CATEGORY_ID = "category_id";

    private static final String TABLE_FAVORITES = "Favoritos";
    public static final String COLUMN_FAVORITE_ID = "_id";
    public static final String COLUMN_FAVORITE_PLATE_ID = "plate_id";
    public static final String COLUMN_FAVORITE_USER_ID = "user_id";


    //Tablas
    private static final String TABLE_CATEGORIES_CREATE =
            "CREATE TABLE " + TABLE_CATEGORIES + " (" +
             COLUMN_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
             COLUMN_CATEGORY_NAME + " TEXT NOT NULL);";

    private static final String TABLE_PLATES_CREATE =
            "CREATE TABLE " + TABLE_PLATES + " (" +
             COLUMN_PLATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
             COLUMN_PLATE_NAME + " TEXT NOT NULL, " +
             COLUMN_PLATE_DESCRIPTION + " TEXT, " +
             COLUMN_PLATE_CATEGORY_ID + " INTEGER, " +
             "FOREIGN KEY(" + COLUMN_PLATE_CATEGORY_ID + ") REFERENCES " + TABLE_CATEGORIES + "(" + COLUMN_CATEGORY_ID + "));";

    public SQLiteOH(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CATEGORIES_CREATE);
        db.execSQL(TABLE_PLATES_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLATES);
        onCreate(db);
    }

    //Insertar categoría
    public void insertarCategoria(String categoryName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, categoryName);

        db.insert(TABLE_CATEGORIES, null, values);
        db.close();
    }

    //Insertar plato
    public void insertarPlato(String plateName, String description, int categoryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PLATE_NAME, plateName);
        values.put(COLUMN_PLATE_DESCRIPTION, description);
        values.put(COLUMN_PLATE_CATEGORY_ID, categoryId);

        db.insert(TABLE_PLATES, null, values);
        db.close();
        }


    public Cursor obtenerPlatosPorCategoria(int categoryId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_PLATE_ID, COLUMN_PLATE_NAME, COLUMN_PLATE_DESCRIPTION};
        String selection = COLUMN_PLATE_CATEGORY_ID + " = ?";
        String[] selectionArgs = {String.valueOf(categoryId)};

        return db.query(TABLE_PLATES, columns, selection, selectionArgs, null, null, null);
    }

    public Cursor obtenerCategorias() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_CATEGORY_ID, COLUMN_CATEGORY_NAME};

        return db.query(TABLE_CATEGORIES, columns, null, null, null, null, null);
    }

    private static final String TABLE_FAVORITES_CREATE =
            "CREATE TABLE " + TABLE_FAVORITES + " (" +
                    COLUMN_FAVORITE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_FAVORITE_PLATE_ID + " INTEGER, " +
                    COLUMN_FAVORITE_USER_ID + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_FAVORITE_PLATE_ID + ") REFERENCES " + TABLE_PLATES + "(" + COLUMN_PLATE_ID + "));";
}


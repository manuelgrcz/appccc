package com.example.cocinaproyect;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Locale;

public class StepFragment extends Fragment {

    private TextView stepTitle;
    private TextView cronometro;
    private Button startTimerButton;
    private long timeLeftInMillis;
    private CountDownTimer countDownTimer;
    private boolean isTimerRunning = false; // Controla el estado del temporizador

    private static final String ARG_TITLE = "title";
    private static final String ARG_TIME = "time";
    private static final String ARG_DESCRIPTION = "description";

    public static StepFragment newInstance(String title, long timeInMillis, String description) {
        StepFragment fragment = new StepFragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putLong(ARG_TIME, timeInMillis);
        args.putString(ARG_DESCRIPTION, description);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_step, container, false);

        // Inicializa las vistas
        stepTitle = rootView.findViewById(R.id.step_title);
        cronometro = rootView.findViewById(R.id.cronometro);
        startTimerButton = rootView.findViewById(R.id.start_timer_boton);

        // Configura los argumentos del fragmento
        if (getArguments() != null) {
            String title = getArguments().getString(ARG_TITLE);
            timeLeftInMillis = getArguments().getLong(ARG_TIME);
            stepTitle.setText(title);
        }

        // Configuración inicial del botón
        startTimerButton.setText("Iniciar");
        startTimerButton.setBackgroundColor(getResources().getColor(R.color.white));

        // Asigna el evento de clic
        startTimerButton.setOnClickListener(v -> toggleTimer());

        return rootView;
    }

    private void toggleTimer() {
        if (isTimerRunning) {
            // Si el temporizador está corriendo, detenerlo
            stopTimer();
        } else {
            // Si el temporizador está detenido, iniciarlo
            startTimer();
        }
    }

    private void startTimer() {
        isTimerRunning = true;
        startTimerButton.setText("Pausar");
        startTimerButton.setBackgroundColor(getResources().getColor(R.color.custom_pink));// Cambia el color del botón

        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                isTimerRunning = false;
                startTimerButton.setText("Iniciar");
                startTimerButton.setBackgroundColor(getResources().getColor(R.color.white));// Reinicia el color del botón
                cronometro.setText("¡Tiempo terminado!");
            }
        }.start();
    }

    private void stopTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        isTimerRunning = false;
        startTimerButton.setText("Iniciar");
        startTimerButton.setBackgroundColor(getResources().getColor(R.color.white)); // Cambia el color de vuelta al inicial
    }

    private void updateTimer() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;
        String timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        cronometro.setText(timeFormatted);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
package com.example.cocinaproyect;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class PlatosFragment extends Fragment {

    private SQLiteOH dbHelper;
    private RecyclerView recyclerView;
    private int categoryId;

    public PlatosFragment() {
        // Constructor vacío
    }

    public static PlatosFragment newInstance(int categoryId) {
        PlatosFragment fragment = new PlatosFragment();
        Bundle args = new Bundle();
        args.putInt("categoryId", categoryId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflar el layout del fragmento
        View rootView = inflater.inflate(R.layout.fragment_platos, container, false);

        // Obtener el categoryId de los argumentos
        if (getArguments() != null) {
            categoryId = getArguments().getInt("categoryId");
        }

        // Inicializar la base de datos
        dbHelper = new SQLiteOH(getContext());

        // Configurar RecyclerView
        recyclerView = rootView.findViewById(R.id.recyclerViewPlates);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Obtener los platos de la base de datos según la categoría seleccionada
        Cursor cursor = dbHelper.obtenerPlatosPorCategoria(categoryId);


        return rootView;
    }

    }

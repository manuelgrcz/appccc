package com.example.cocinaproyect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Usamos el método setOnNavigationItemSelectedListener para manejar la selección
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment currentFragment = fragmentManager.findFragmentById(R.id.fragmentContainer);

            if (item.getItemId() == R.id.page_inicio) {
                // Si ya estás en MainActivity, no haces nada
                if (currentFragment != null) {
                    // Regresamos a la página inicial, por ejemplo, eliminando el fragmento cargado
                    getSupportFragmentManager().popBackStack(); // Esto elimina el fragmento actual
                }

                return true;
            } else if (item.getItemId() == R.id.page_favoritos) {
                // Llama a FavoritosActivity cuando se selecciona "Favoritos"
                Intent intent = new Intent(MainActivity.this, FavoritosActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });
    }

    public void goToArroces(View view) {
        replaceFragment(new ArrocesFragment());
    }


    public void goToItaliana(View view) {
        replaceFragment(new ItalianaFragment());
    }


    public void goToVegana(View view) {
        replaceFragment(new VeganaFragment());
    }


    public void goToPostres(View view) {
        replaceFragment(new PostresFragment());
    }


    private void replaceFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}



package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class RisotoSetaActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.risoto_seta_activity);

        recyclerView = findViewById(R.id.risoto_seta);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes",
                "Para 4 personas: " +
                "400 g. de arroz. " +
                "1.5l. de caldo de verduras. " +
                "300 g. de setas. " +
                "100 g. de cebolla. " +
                "100 g. de queso parmesano. " +
                "150 ml. de vino blanco. " +
                "Sal. ", false, 0));
        recipeSteps.add(new RecipeStep("Prepara la cebolla", "Pica la cebolla y póchala en un poco de aceite a fuego medio-bajo", true, 500000));

        recipeSteps.add(new RecipeStep("Incorpora ingredientes","Mientras se pocha, trocea las setas y añádelas y cocina durante unos minutos. Luego añade el arroz y remueve" ,false, 0));

        recipeSteps.add(new RecipeStep("Prepara los líquidos", "Añade el vino y sube el fuego para que se evapore el alcohol. Calienta el caldo de verdura", false, 0));

        recipeSteps.add(new RecipeStep("Añade el caldo", "Cuando se evapore el alcohol, baja el fuego a medio y añade caldo poco a poco para que se incorpore bien a la mezcla", true, 2000000));

        recipeSteps.add(new RecipeStep("Aporta la textura", "Cuando el arroz esté en su punto, añade queso poco a poco. Verás cómo el caldo se densifica", false, 0));

        recipeSteps.add(new RecipeStep("Ya está listo", "Cuando coja el punto de cremosidad deseado, puedes emplatar y decorar con algún crocanti. ¡A DISFRUTAR!", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("risoto_seta");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("risoto_seta", "Risoso de Seta");
            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                ;
                editor.remove("risoto_seta");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
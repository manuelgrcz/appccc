package com.example.cocinaproyect;

import android.app.AlertDialog;
import android.content.Context;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class StepAdapter extends RecyclerView.Adapter<StepAdapter.StepViewHolder> {

    private List<RecipeStep> steps;
    private Context context;

    public StepAdapter(List<RecipeStep> steps, Context context) {
        this.steps = steps;
        this.context = context;
    }

    @NonNull
    @Override
    public StepViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.fragment_step, parent, false);
        return new StepViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StepViewHolder holder, int position) {
        RecipeStep step = steps.get(position);
        System.out.println(Integer.toString(position));
        holder.descriptionTextView.setText(step.getTitle());

        if (step.hasTimer()) {
            holder.cronometro.setVisibility(View.VISIBLE);
            holder.startTimerButton.setVisibility(View.VISIBLE);
            holder.reset.setVisibility(View.VISIBLE);

            // Configura el botón para iniciar el temporizador
            holder.startTimerButton.setOnClickListener(v -> {
                if (holder.countDownTimer != null) {
                    holder.countDownTimer.cancel(); // Cancela cualquier temporizador previo
                }

                if (holder.isTimerRunning) { // Si el temporizador está en marcha, lo pausamos
                    holder.countDownTimer.cancel();
                    holder.isTimerRunning = false;
                    holder.startTimerButton.setText("Iniciar"); // Cambia el texto a "Iniciar"
                } else { // Si el temporizador está detenido, lo iniciamos
                    holder.countDownTimer = new CountDownTimer(step.getTimerDuration(), 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {
                            // Actualiza el texto del temporizador
                            long seconds = millisUntilFinished / 1000;
                            holder.cronometro.setText(String.format("%02d:%02d", seconds / 60, seconds % 60));
                        }

                        @Override
                        public void onFinish() {
                            // Manejo del temporizador finalizado
                            holder.cronometro.setText("00:00");
                            holder.isTimerRunning = false;
                            holder.startTimerButton.setText("Iniciar"); // Cambia el texto a "Iniciar" al terminar
                        }
                    }.start();
                    holder.isTimerRunning = true;
                    holder.startTimerButton.setText("Pausar"); // Cambia el texto a "Pausar"
                }
            });


            // Configura el botón para reiniciar el temporizador
            holder.reset.setOnClickListener(v -> {
                if (holder.countDownTimer != null) {
                    holder.countDownTimer.cancel(); // Cancela el temporizador actual
                }
                holder.cronometro.setText(String.format("%02d:%02d",
                        step.getTimerDuration() / 1000 / 60,
                        step.getTimerDuration() / 1000 % 60));
                holder.startTimerButton.setText("Iniciar");
                holder.isTimerRunning = false;// Reinicia el texto al valor original
            });
        } else {
            holder.cronometro.setVisibility(View.GONE);
            holder.startTimerButton.setVisibility(View.GONE);
            holder.reset.setVisibility(View.GONE);
        }
        holder.descriptionButton.setOnClickListener(v -> {
            // Crear y mostrar el diálogo
            new AlertDialog.Builder(holder.itemView.getContext())
                    .setTitle("Información")
                    .setMessage(step.getDescription()) // Usa el texto que quieras mostrar
                    .setPositiveButton("Aceptar", (dialog, which) -> {
                        dialog.dismiss(); // Cierra el diálogo
                    })
                    .create()
                    .show();
        });
    }


    @Override
    public int getItemCount() {
        return steps.size();
    }

    public void startTimer(TextView cronometro, long duration) {
        new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int minutes = (int) (millisUntilFinished / 1000) / 60;
                int seconds = (int) (millisUntilFinished / 1000) % 60;
                String timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
                cronometro.setText(timeFormatted);
            }

            @Override
            public void onFinish() {
                cronometro.setText("¡Tiempo terminado!");
            }
        }.start();
    }

    public static class StepViewHolder extends RecyclerView.ViewHolder {

        private CountDownTimer countDownTimer; //
        public TextView descriptionTextView;
        public  TextView cronometro;
        public Button startTimerButton;
        public Button reset;
        public Button descriptionButton;

        public boolean isTimerRunning = false;
        public StepViewHolder(View itemView) {
            super(itemView);
            descriptionTextView = itemView.findViewById(R.id.step_title);
            cronometro = itemView.findViewById(R.id.cronometro);
            startTimerButton = itemView.findViewById(R.id.start_timer_boton);
            reset = itemView.findViewById(R.id.reset_boton);
            descriptionButton = itemView.findViewById(R.id.descripcion_boton);
        }
    }
}



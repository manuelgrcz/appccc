

package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class EspaguetisBoloActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.espaguetis_bolo_activity);

        recyclerView = findViewById(R.id.espaguetis);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!",
                "1/2 cebolla. " +
                "2 dientes de ajo. " +
                "1 zanahoria. " +
                "1 chorrito de vino blanco. " +
                "30 g. de soja texturizada. " +
                "400 g. de tomate triturado. " +
                "Parmesano al gusto. " +
                "180 g. de espaguetis. ", false, 0));
        recipeSteps.add(new RecipeStep("Haz el sofrito", "Corta en trocitos la cebolla, los ajos y los zanahorias. Incorpóralos al fuego medio y sofríe", true, 1200000));

        recipeSteps.add(new RecipeStep("Prepara la salsa","Añade al sofrito el tomate triturado con un chorrito de vino blanco. Condimenta al gusto y salpimenta. Deja cocinar" ,true, 300000));

        recipeSteps.add(new RecipeStep("Cuece la pasta", "Recuerda echar un poco de aceite al agua en el que cocinarás los espaguetis y una pizca de sal", false, 0));

        recipeSteps.add(new RecipeStep("Ya está listo", "Decora al gusto y ¡QUÉ APROVECHE", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("espaguetis_bolo");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("espaguetis_bolo", "Espaguetis Boloñesa");
            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                ;
                editor.remove("espaguetis_bolo");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
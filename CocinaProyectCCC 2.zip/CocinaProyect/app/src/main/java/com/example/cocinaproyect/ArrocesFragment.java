package com.example.cocinaproyect;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class ArrocesFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_arroces, container, false);

        Button[] buttons = new Button[] {
                rootView.findViewById(R.id.arroz_negro),
                rootView.findViewById(R.id.risoto_seta),
                rootView.findViewById(R.id.arroz_cubana),
                rootView.findViewById(R.id.ensalada_arroz)
        };

        Class[] activities = new Class[] {
                ArrozNegroActivity.class,
                RisotoSetaActivity.class,      // Reemplaza con el nombre real de tu actividad
                ArrozCubanaActivity.class,    // Reemplaza con el nombre real de tu actividad
                EnsaladaArrozActivity.class     // Reemplaza con el nombre real de tu actividad
        };;
        for (int i = 0; i < buttons.length; i++) {
            final int index = i; // Necesario para usar en el listener, ya que 'i' debe ser final
            buttons[i].setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), activities[index]);
                startActivity(intent);
            });
        }


        return rootView;
    }
}


package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class ArrozCubanaActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.arroz_cubana_activity);

        recyclerView = findViewById(R.id.arroz_cubana);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!", "Receta para 2: " +
                "200 g. de arroz. " +
                "2 huevos. " +
                "Tomate . " +
                "1 plátano. " +
                "1 diente de ajo. " +
                "200 ml. de agua. ", false, 0));

        recipeSteps.add(new RecipeStep("Haz los ajos y el arroz",
                "Pon aceite en una olla y enciende el fuego a nivel medio-alto. Lamina el ajo e incorpóralo. Cocina hasta que se dore y entonces añade el arroz y dóralo removiendo", false, 0));

        recipeSteps.add(new RecipeStep("Toca hervir","Baja el fuego a fuego bajo. Añade el agua y deja cocinar con la tapa entreabierta. Mientras, ¡a por el siguiente paso!" ,true, 720000));

        recipeSteps.add(new RecipeStep("Corta y pela los plátanos", "Corta los plátanos por los extremos, pélalos y cortalos a la mitad longitudinalmente. Fríe vuelta y vuelta. Una vez listos, colócalos en un papel absorbente", false, 0));

        recipeSteps.add(new RecipeStep("Fríe los huevos", "Puedes freírlos en la misma sartén que en la que cocinaste los huevos", false, 0));

        recipeSteps.add(new RecipeStep("¡Está listo!", "¡A DISFRUTAR!", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("arroz_cubana");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("arroz_cubana", "Arroz Cubana");
            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                editor.remove("arroz_cubana");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}


package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class FalafelActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.falafel_activity);


        recyclerView = findViewById(R.id.falafel);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!",
                "(Recuerda poner los garbanzos a remojo un día antes) Para 15-20 unidades: " +
                "200 g. de garbanzos. " +
                "35 g. de espinacas frescas. " +
                "2 cucharaditas de comino. "  +
                "1 cucharadite de levadura en polvo. " +
                "1 cucharadita de pimentón picante. " +
                "1 cucharadita de ajo en polvo. " +
                "Perejil. " +
                "El zumo de 1/2 limón. " +
                "Sal."
                , false, 0));
        recipeSteps.add(new RecipeStep("Tritura", "Tritura los garbanzos. Prueba a no triturarlos perfectamente. Deja texturas. Tritura las espinacas con el perejil y mézclalo todo.", false, 0));

        recipeSteps.add(new RecipeStep("Termina la mezcla","Añade las especias, el ajo, la sal y la levadura con un chorrito de limón. Mezcla hasta que se integre bien. Deja reposar" ,false, 0));

        recipeSteps.add(new RecipeStep("Prepara las bolas", "Haz las bolas y calienta el aceite. Fríelas hasta que estén bien hechas", false, 0));

        recipeSteps.add(new RecipeStep("A comer", "¡Ya están lista! Puedes acompañarlas con salsa de yogur. ¡Están riquísimas!", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);



        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("falafel");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("falafel", "Falafel vegano");


            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                editor.remove("falafel");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
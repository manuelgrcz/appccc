

package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class CalamarActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calamar_activity);

        recyclerView = findViewById(R.id.calamar);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!", "Para 4 personas: " +
                "300 g. de espaguetis. " +
                "680 g. de puré de tomate en conserva. " +
                "1 diente de ajo. " +
                "25g. de miga de pan rallado. " +
                "40 g. de alcaparras. " +
                "25 g. de perejil. " +
                "4 calamares medianos. " +
                "1 cebolla roja. " +
                "1 huevo. " +
                "40 g. de parmesano. " +
                "Aceite de oliva. " +
                "12 hojas de albahaca. ", true, 60000));

        recipeSteps.add(new RecipeStep("Sofrito", "Calienta el aceite en una olla rápida. Corta en dados la cebolla y cocínala. Añade 15 g. de" +
                "alcaparras, albahace y el tomate.", true, 30000));

        recipeSteps.add(new RecipeStep("Rellena los calamares","Pon en unn bol: 1 huevo, 1 diente de ajo picado," +
                "25 g. de alcaparras, pan rallado, queso rallado, 20 g. de perejil, 2 cucharadas de agua y 1 de aceite. Mezcla bien y rellena. Cierra los calamares con un palillo" ,false, 0));

        recipeSteps.add(new RecipeStep("Cocina los calamares", "Introdúcelos en la olla junto con los tentáculos. Sazona y cocina con la olla cerrada", true, 30000));

        recipeSteps.add(new RecipeStep("El turno de los espaguetis", "Retira los calamares de la olla. Cuece los calamares según el tiempo recomendado. Una vez cocidos, mezcla con la salsa", false, 0));

        recipeSteps.add(new RecipeStep("¡A comer!", "Reparte la pasta y coloca un calamar en rodajas para decorar", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);

        String recipeKey = "calamares";

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("calamares");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("calamares", "Calamares");
            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                editor.remove("calamares");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
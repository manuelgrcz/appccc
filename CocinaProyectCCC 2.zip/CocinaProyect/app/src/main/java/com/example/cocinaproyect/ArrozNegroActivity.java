

package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

        public class ArrozNegroActivity extends AppCompatActivity {

            private int currentStepIndex = 0;

            private Button prevButton;
            private Button nextButton;

            private RecyclerView recyclerView;

            private StepAdapter stepAdapter;
            private ViewPager viewPager;
            private StepPagerAdapter pagerAdapter;
            private List<RecipeStep> recipeSteps;
            private boolean isFavorite = false;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.arroz_negro_activity);

                recyclerView = findViewById(R.id.receta_arroz_negro);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));

                recipeSteps = new ArrayList<>();

                recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!",
                        "Receta para 2: " +
                        "180 g. de arroz. " +
                        "2 calamares. " +
                        "1 tomate. " +
                        "1/2 cebolleta. " +
                        "1/2 pimiento verde. " +
                        "500 ml de fumet. " +
                        "2-3 sobres de tinta de calamar. " +
                        "Sal. ",
                        false, 0));
                recipeSteps.add(new RecipeStep("Pocha la cebolleta y el pimiento",
                        "A fuego medio-bajo, cocina los ingredientes durante 10 minutos. Mientras, corta el tomate en dados pequeños y quita las pepitas. ", true, 600000));

                recipeSteps.add(new RecipeStep("Añade el tomate.","Rehogamos todo el sofrito. Limpiamos y cortamos los calamares" ,true, 900000));

                recipeSteps.add(new RecipeStep("Ahora añade los calamares", "Cocínalo todo junto durante 5 minutos. Añade sal. ", true, 300000));

                recipeSteps.add(new RecipeStep("Incorpora el arroz", "Rehoga el arroz otros 5 minutos. ¡Vigila que no se pegue!", true, 18000));

                recipeSteps.add(new RecipeStep("¡Ya solo falta el sabor!", "Añade el fumet y la tinta y lo mantenemos a fuego medio bajo", true, 1080000));

                recipeSteps.add(new RecipeStep("¡Está listo", "¡A DISFRUTAR! ", false, 0));

                stepAdapter = new StepAdapter(recipeSteps, this);
                //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
                recyclerView.setAdapter(stepAdapter);

                prevButton = findViewById(R.id.anterior_boton);
                nextButton = findViewById(R.id.siguiente_boton);

                prevButton.setOnClickListener(v -> goToPreviousStep());
                nextButton.setOnClickListener(v -> goToNextStep());

                // Inicializa el primer paso
                updateStepView();


                ImageButton botonfavorito = findViewById(R.id.favorite_btn);

                SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
                isFavorite = preferences.contains("arroz_negro");

                botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

                botonfavorito.setOnClickListener(v -> {
                    isFavorite = !isFavorite;
                    SharedPreferences.Editor editor = preferences.edit();

                    if (isFavorite) {
                        botonfavorito.setImageResource(R.drawable.fav_logo_active);
                        Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                        editor.putString("arroz_negro", "Arroz Negro");
                    } else {
                        botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                        Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                        editor.remove("arroz_negro");
                    }
                    editor.apply();
                });

            }

            private void goToPreviousStep() {
                if (currentStepIndex > 0) {
                    currentStepIndex--;
                    updateStepView();
                }
            }

            private void goToNextStep() {
                if (currentStepIndex < recipeSteps.size() - 1) {
                    currentStepIndex++;
                    updateStepView();
                }
            }

            private void updateStepView() {
                // Desplaza el RecyclerView al paso actual
                recyclerView.smoothScrollToPosition(currentStepIndex);

                // Actualiza la habilitación de los botones
                prevButton.setEnabled(currentStepIndex > 0);
                nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
            }

            @Override
            public boolean onOptionsItemSelected(MenuItem item) {
                if (item.getItemId() == android.R.id.home) {
                    onBackPressed();
                    return true;
                }
                return super.onOptionsItemSelected(item);
            }
        }
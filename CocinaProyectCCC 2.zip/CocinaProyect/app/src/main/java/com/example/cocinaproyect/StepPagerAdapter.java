package com.example.cocinaproyect;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.List;


public class StepPagerAdapter extends FragmentStatePagerAdapter {
    private List<RecipeStep> recipesteps;

    public StepPagerAdapter(@NonNull FragmentManager fm, List<RecipeStep> steps) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.recipesteps = steps;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        RecipeStep step = recipesteps.get(position);
        return StepFragment.newInstance(
                step.getTitle(),
                step.getTimerDuration(),
                step.getDescription());
    }

    @Override
    public int getCount() {
        return recipesteps.size();
    }
}
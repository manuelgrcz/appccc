

package com.example.cocinaproyect;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class LasagnaActivity extends AppCompatActivity {

    private int currentStepIndex = 0;

    private Button prevButton;
    private Button nextButton;

    private RecyclerView recyclerView;

    private StepAdapter stepAdapter;
    private ViewPager viewPager;
    private StepPagerAdapter pagerAdapter;
    private List<RecipeStep> recipeSteps;
    private boolean isFavorite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lasagna_activity);

        recyclerView = findViewById(R.id.lasagna);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recipeSteps = new ArrayList<>();

        recipeSteps.add(new RecipeStep("¡Reúne los ingredientes!",
                "350 g. de tomate. " +
                "9 láminas de pasta. " +
                "300 g. de calabacín. " +
                "300 g. de berenjena. " +
                "200 g. de pimiento rojo. " +
                "200 g. de pimiento verde. " +
                "300 g. de cebolla. " +
                "60 g. de queso rallado. " +
                "Aceite de oliva. " +
                "Orégano, sal y pimienta. ", true, 60000));
        recipeSteps.add(new RecipeStep("Prepara la verdura 1", "Corta en dados toda la verdura. Calienta el aceite en una sartén e incorpora la cebolla y los pimientos", true, 600000));

        recipeSteps.add(new RecipeStep("Prepara la verdura 2","Añade el calabacín y la berenjena. No te olvides de salpimentar" ,true, 600000));

        recipeSteps.add(new RecipeStep("Añade el tomate", "Viértelo y sofríe todo junto", true, 300000));

        recipeSteps.add(new RecipeStep("Prepara las placas", "Hidrata la pasta según el fabricante y deja reposar", false, 0));

        recipeSteps.add(new RecipeStep("Prepara la lasaña", "En una fuente monta la cebolla, la pasta y la salsa por capas en este orden. ¡Añade una primera capa de salsa para que no se pegue!", false, 0));

        recipeSteps.add(new RecipeStep("Hornea la lasaña", "Prepara el horno a 180ª", true, 1800000));

        recipeSteps.add(new RecipeStep("Ya casi está", "Añade queso rallado y gratina", true, 300000));

        recipeSteps.add(new RecipeStep("Retírala del horno", "Déjala reposar ¡Está muy caliente", false, 0));

        stepAdapter = new StepAdapter(recipeSteps, this);
        //pagerAdapter = new StepPagerAdapter(getSupportFragmentManager(), recipeSteps);
        recyclerView.setAdapter(stepAdapter);

        prevButton = findViewById(R.id.anterior_boton);
        nextButton = findViewById(R.id.siguiente_boton);

        prevButton.setOnClickListener(v -> goToPreviousStep());
        nextButton.setOnClickListener(v -> goToNextStep());

        // Inicializa el primer paso
        updateStepView();


        ImageButton botonfavorito = findViewById(R.id.favorite_btn);

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        isFavorite = preferences.contains("lasagna");

        botonfavorito.setImageResource(isFavorite ? R.drawable.fav_logo_active : R.drawable.fav_logo_inactive);

        botonfavorito.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            SharedPreferences.Editor editor = preferences.edit();

            if (isFavorite) {
                botonfavorito.setImageResource(R.drawable.fav_logo_active);
                Toast.makeText(this, "Añadido a favoritos", Toast.LENGTH_SHORT).show();
                editor.putString("lasagna", "Lasagna");
            } else {
                botonfavorito.setImageResource(R.drawable.fav_logo_inactive);
                Toast.makeText(this, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                ;
                editor.remove("lasagna");
            }
            editor.apply();
        });

    }

    private void goToPreviousStep() {
        if (currentStepIndex > 0) {
            currentStepIndex--;
            updateStepView();
        }
    }

    private void goToNextStep() {
        if (currentStepIndex < recipeSteps.size() - 1) {
            currentStepIndex++;
            updateStepView();
        }
    }

    private void updateStepView() {
        // Desplaza el RecyclerView al paso actual
        recyclerView.smoothScrollToPosition(currentStepIndex);

        // Actualiza la habilitación de los botones
        prevButton.setEnabled(currentStepIndex > 0);
        nextButton.setEnabled(currentStepIndex < recipeSteps.size() - 1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
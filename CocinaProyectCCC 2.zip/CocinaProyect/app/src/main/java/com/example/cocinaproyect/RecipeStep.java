package com.example.cocinaproyect;

public class RecipeStep {


    private String title;
    private String description;
    private boolean hasTimer;
    private long timerDuration;


    public RecipeStep(String title, String description, boolean hasTimer, long timerDuration) {
        this.title = title;
        this.description = description;
        this.hasTimer = hasTimer;
        this.timerDuration = timerDuration;
    }
    public String getTitle(){ return title; }

    public String getDescription() { return description; }

    public boolean hasTimer() {
        return hasTimer;
    }

    public long getTimerDuration() {
        return timerDuration;
    }
}

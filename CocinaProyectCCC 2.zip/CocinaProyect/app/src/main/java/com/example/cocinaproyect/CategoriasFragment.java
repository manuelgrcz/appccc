package com.example.cocinaproyect;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cocinaproyect.CategoryAdapter;
import com.example.cocinaproyect.R;
import com.example.cocinaproyect.SQLiteOH;

public class CategoriasFragment extends Fragment {

    private SQLiteOH dbHelper;
    private RecyclerView recyclerView;
    private CategoryAdapter categoryAdapter;

    public CategoriasFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflar el layout del fragmento
        View rootView = inflater.inflate(R.layout.fragment_categorias, container, false);

        // Inicializar la base de datos
        dbHelper = new SQLiteOH(getContext());

        // Configurar RecyclerView
        recyclerView = rootView.findViewById(R.id.recyclerViewCategories);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Obtener las categorías de la base de datos
        Cursor cursor = dbHelper.obtenerCategorias();

        // Crear el adaptador y asignarlo al RecyclerView
        categoryAdapter = new CategoryAdapter(getContext(), cursor);
        recyclerView.setAdapter(categoryAdapter);

        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (categoryAdapter != null) {
            categoryAdapter.swapCursor(null);
        }
    }
}

package com.example.cocinaproyect;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Map;

public class FavoritosActivity extends AppCompatActivity {

    private LinearLayout favoritosContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);

        favoritosContainer = findViewById(R.id.favorite_layout);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Usamos el método setOnNavigationItemSelectedListener para manejar la selección
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.page_favoritos) {
                // Si ya estás en MainActivity, no haces nada
                return true;
            } else if (item.getItemId() == R.id.page_inicio) {
                // Llama a FavoritosActivity cuando se selecciona "Favoritos"
                Intent intent = new Intent(FavoritosActivity.this, MainActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });

        SharedPreferences preferences = getSharedPreferences("favorites", MODE_PRIVATE);
        Map<String, ?> favorites = preferences.getAll();

        if (favorites.isEmpty()) {
            TextView emptyMessage = new TextView(this);
            emptyMessage.setText("No hay favoritos");
            favoritosContainer.addView(emptyMessage);
            return;
        }


        // Crear un botón para cada receta favorita
        for (Map.Entry<String, ?> entry : favorites.entrySet()) {
            String recipeKey = entry.getKey();
            String recipeName = entry.getValue().toString();

            Button recipeButton = new Button(this);
            recipeButton.setText(recipeName);

            // Configurar la acción al pulsar el botón
            recipeButton.setOnClickListener(v -> {
                        Intent intent = null;

                        if (recipeKey.equals("arroz_negro")) {
                            intent = new Intent(FavoritosActivity.this, ArrozNegroActivity.class);

                        } else if (recipeKey.equals("bizcocho")){
                            intent = new Intent(FavoritosActivity.this, BizcochoZanahoriaActivity.class);

                        } else if (recipeKey.equals("arroz_cubana")) {
                            intent = new Intent(FavoritosActivity.this, ArrozCubanaActivity.class);

                        } else if (recipeKey.equals("calamares")) {
                            intent = new Intent(FavoritosActivity.this, CalamarActivity.class);

                        } else if (recipeKey.equals("crepes")) {
                            intent = new Intent(FavoritosActivity.this, CrepesActivity.class);

                        } else if (recipeKey.equals("ensalada-arroz")) {
                            intent = new Intent(FavoritosActivity.this, EnsaladaArrozActivity.class);

                        } else if (recipeKey.equals("espaguetis_bolo")) {
                            intent = new Intent(FavoritosActivity.this, EspaguetisBoloActivity.class);

                        } else if (recipeKey.equals("falafel")) {
                            intent = new Intent(FavoritosActivity.this, FalafelActivity.class);

                        } else if (recipeKey.equals("judias_blancas")) {
                            intent = new Intent(FavoritosActivity.this, JudiasBlancasActivity.class);

                        } else if (recipeKey.equals("lasagna")) {
                            intent = new Intent(FavoritosActivity.this, LasagnaActivity.class);

                        } else if (recipeKey.equals("lentejas")) {
                            intent = new Intent(FavoritosActivity.this, LentejasActivity.class);

                        } else if (recipeKey.equals("patatas_importancia")) {
                            intent = new Intent(FavoritosActivity.this, PatatasImportanciaActivity.class);

                        } else if (recipeKey.equals("pizza")) {
                            intent = new Intent(FavoritosActivity.this, PizzaActivity.class);

                        } else if (recipeKey.equals("risoto_seta")) {
                            intent = new Intent(FavoritosActivity.this, RisotoSetaActivity.class);

                        } else if (recipeKey.equals("sorbete_limon")) {
                            intent = new Intent(FavoritosActivity.this, SorbeteLimonActivity.class);

                        } else if (recipeKey.equals("tarta_melocoton")) {
                            intent = new Intent(FavoritosActivity.this, TartaMelocotonActivity.class);

                        } else {
                            Toast.makeText(this, "Receta no disponible", Toast.LENGTH_SHORT).show();
                        }

                        if (intent != null) {
                            startActivity(intent);
                        }
                    });

            // Agregar el botón al contenedor
            favoritosContainer.addView(recipeButton);
        }
    }
}

